DART public data collectors
Python 3.11+ standard library. Extract scripts into repository root.
Run: python scripts/refresh_core.py
Then: python scripts/matchup_context.py
Then: python scripts/availability.py
Then: python scripts/matchup_environment.py
Requires model.json, data.json, history.json, context-history-inputs.json from the website repository.
These collectors refresh evidence, not model weights. They do not schedule themselves.
