import importlib.util,json,pathlib,unittest
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('context',R/'scripts/matchup_context.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class ContextTests(unittest.TestCase):
 def test_win_is_outright(self):
  g=dict(id='test',home='a',away='b',hs=20,**{'as':21})
  self.assertEqual(m.result(g,'a'),-1)
  self.assertEqual(m.record([g],'a')['wins'],0)
 def test_empty_record_is_unknown_not_zero_scoring(self):
  r=m.record([],'a');self.assertEqual(r['games'],0);self.assertIsNone(r['pointsFor']);self.assertIsNone(r['pointsAgainst'])
 def test_night_timezone(self):
  self.assertTrue(m.night({'date':'2026-10-25T00:00Z'}));self.assertFalse(m.night({'date':'2026-10-24T21:00Z'}))
 def test_all_forecasts_have_context(self):
  d=json.loads((R/'dist/matchup-context.json').read_text());f=json.loads((R/'dist/model.json').read_text())
  self.assertEqual(set(d['games']),{g['id'] for g in f['forecasts']})
  for g in d['games'].values():
   self.assertEqual(g['modelUse'],'contextOnly')
   self.assertIn('statisticsThrough',g)
   for s in g['sections'].values():
    self.assertEqual(s['modelUse'],'contextOnly')
    for i in s['items']:
     self.assertTrue(i['title']);self.assertTrue(i['text']);self.assertTrue(i['sourceUrl'])
   for t in g['teams'].values():
    self.assertIn('Game-summary coverage:',t['rankedCoverage'])
    for r in t['splits'].values():
     if r:self.assertEqual(r['wins']+r['losses']+r['ties'],r['games'])
if __name__=='__main__':unittest.main()
