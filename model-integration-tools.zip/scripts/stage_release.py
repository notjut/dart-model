"""Stage a synchronized release; never overwrite previously issued predictions."""
import datetime as dt, hashlib, json, pathlib, shutil
R=pathlib.Path(__file__).resolve().parents[1];D=R/'dist';S=R/'release';S.mkdir(exist_ok=True)
read=lambda n:json.loads((D/n).read_text())
base=read('model.json');fresh=read('model-refreshed.json');candidate=read('model-context-candidate.json');data=read('current-data.json');quotes=read('current-game-details.json');context=read('matchup-context.json')
assert data['asOf']==fresh['asOf']
assert not data['failures'] and not quotes['failures']
assert {x['id'] for x in fresh['heldout']}=={x['id'] for x in candidate['heldout']}
now=dt.datetime.now(dt.timezone.utc);games={g['id']:g for g in data['games']}
forecasts=[f for f in fresh['forecasts'] if f['id'] in context['games'] and not games[f['id']]['done'] and dt.datetime.fromisoformat(games[f['id']]['date'].replace('Z','+00:00'))>now]
assert forecasts
for f in forecasts:
 assert f['id'] in quotes['games']
 assert abs(f['coreMargin']-f['coreIntercept']-sum(c['points'] for c in f['coreContributions']))<.1
 assert f['coreSd']>=10
# Keep the published evaluation cohort unchanged, with explicit independent dates.
release={**base,'forecasts':forecasts,'trainedGames':fresh['trainedGames'],'asOf':fresh['asOf'],'generatedAt':fresh['generatedAt'],'inputRetrievedAt':fresh['inputRetrievedAt'],'evaluationFrozenThrough':base['testEnd'],'latestReplay':fresh['core']}
audit={'generatedAt':now.isoformat(),'forecastAsOf':data['asOf'],'forecasts':len(forecasts),'evaluationGames':fresh['testedGames'],'baseline':fresh['core'],'candidate':candidate['core'],'candidatePromoted':False,'reason':'Additional split factors increased winner accuracy but worsened margin error and Brier score. Retain existing core feature set.','limits':['Retrospective expanding-date evaluation, not new independent live results.','Current injuries, QB experience and weather lack historical as-known-at-kickoff coverage; no fitted effects.','Automatic refresh is not enabled by this release.'],'publishedEvaluationThrough':base['testEnd'],'inputHashes':{n:hashlib.sha256((D/n).read_bytes()).hexdigest() for n in ['current-data.json','current-game-details.json','matchup-context.json','availability.json','matchup-environment.json']}}
for n,obj in [('model.json',release),('model-archive-2026-10-20.json',base),('data.json',data),('game-details.json',quotes),('integration-audit.json',audit)]:
 (S/n).write_text(json.dumps(obj,separators=(',',':'),allow_nan=False))
for n in ['app.js','index.html','context.js']:
 s=(D/n).read_text()
 if n=='app.js':
  s=s.replace('October 20 snapshot',"${D.asOf} forecast inputs").replace('fetch(u);','fetch(u,{cache:"no-cache"});')
 if n=='index.html':
  s=s.replace('OCT 20, 2026 SNAPSHOT','OCT 24, 2026 FORECAST INPUTS').replace('October 20 data snapshot','October 24 data snapshot').replace('saved October 20 snapshot','saved October 24 snapshot')
  s=s.replace('src="context.js"','src="context.js?v=20261024-3"').replace('src="app.js"','src="app.js?v=20261024-3"')
  s=s.replace('If no line is posted, it is labeled as a model-underdog estimate; pick’em games show no underdog percentage.','Missing spreads and pick’em games have no market underdog and no upset percentage.')
  s=s.replace('<section id="test" class="tab" hidden>', '<section id="test" class="tab" hidden><div class="notice">Historical evaluation below retains its original test cohort through October 18. Current forecasts were rebuilt from October 24 inputs. <a href="integration-audit.json">Latest integration test</a> · <a href="model-archive-2026-10-20.json">Archived October 20 forecasts</a>.</div>')
  s=s.replace('id="validation"', 'id="validation"')
 if n=='context.js':
  s=s.replace('Main forecast uses results through ${esc(D.asOf)}.', 'Main forecast uses results through ${esc(D.asOf)}. Historical evaluation remains frozen through ${esc(M.evaluationFrozenThrough||M.testEnd)}.')
 (S/n).write_text(s)
print(json.dumps(audit,indent=2))
